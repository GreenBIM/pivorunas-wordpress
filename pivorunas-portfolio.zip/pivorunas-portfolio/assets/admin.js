( function ( $ ) {
	function row( attachment ) {
		var thumb = attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;
		return $(
			'<li data-id="' + attachment.id + '">' +
				'<img alt="" src="' + thumb + '" width="72" height="72" />' +
				'<span></span>' +
				'<button type="button" class="button-link" data-pivorunas-remove">Remove</button>' +
				'<input type="hidden" name="pivorunas_frames[]" />' +
			'</li>'
		).find( 'span' ).text( attachment.title || attachment.filename || '' ).end()
			.find( 'input' ).val( attachment.id ).end();
	}

	$( document ).on( 'click', '[data-pivorunas-add-frames]', function ( event ) {
		event.preventDefault();
		var list = $( '[data-pivorunas-frames]' );
		var frame = wp.media( { title: 'Photographs', multiple: true, library: { type: 'image' } } );
		frame.on( 'select', function () {
			frame.state().get( 'selection' ).each( function ( model ) {
				list.append( row( model.toJSON() ) );
			} );
		} );
		frame.open();
	} );

	$( document ).on( 'click', '[data-pivorunas-remove]', function ( event ) {
		event.preventDefault();
		$( this ).closest( 'li' ).remove();
	} );

	$( document ).on( 'click', '[data-pivorunas-add-video]', function ( event ) {
		event.preventDefault();
		var box = $( '[data-pivorunas-video]' );
		var frame = wp.media( { title: 'Video', multiple: false, library: { type: 'video' } } );
		frame.on( 'select', function () {
			var file = frame.state().get( 'selection' ).first().toJSON();
			box.find( 'input' ).val( file.id );
			box.find( '[data-pivorunas-video-name]' ).text( file.filename || file.title || '' );
		} );
		frame.open();
	} );

	$( document ).on( 'click', '[data-pivorunas-clear-video]', function ( event ) {
		event.preventDefault();
		var box = $( '[data-pivorunas-video]' );
		box.find( 'input' ).val( '' );
		box.find( '[data-pivorunas-video-name]' ).text( '' );
	} );

	$( document ).on( 'click', '[data-pivorunas-landing-add]', function ( event ) {
		event.preventDefault();
		var form = $( '#pivorunas-landing-form' );
		var frame = wp.media( { title: 'Landing page images', multiple: true, library: { type: 'image' } } );
		frame.on( 'select', function () {
			var ids = [];
			frame.state().get( 'selection' ).each( function ( model ) {
				ids.push( model.id );
			} );
			if ( ! ids.length ) {
				return;
			}
			form.find( '[name="pivorunas_add_ids"]' ).val( ids.join( ',' ) );
			form.find( '[name="pivorunas_action"]' ).val( 'add' );
			form.get( 0 ).submit();
		} );
		frame.open();
	} );

	function pivorunasLandingRefresh() {
		var boxes = $( '#pivorunas-landing-form tbody input[type="checkbox"]' );
		var checked = boxes.filter( ':checked' );
		var toggle = $( '[data-pivorunas-landing-toggle]' );
		var remove = $( '[data-pivorunas-landing-delete]' );
		remove.prop( 'disabled', checked.length === 0 );
		if ( ! checked.length ) {
			toggle.prop( 'disabled', true ).val( 'activate' ).text( 'Activate' );
			return;
		}
		var allOn = checked.toArray().every( function ( box ) {
			return box.getAttribute( 'data-active' ) === '1';
		} );
		toggle.prop( 'disabled', false ).val( allOn ? 'deactivate' : 'activate' ).text( allOn ? 'Deactivate' : 'Activate' );
	}

	$( document ).on( 'change', '#pivorunas-landing-form tbody input[type="checkbox"], [data-pivorunas-landing-all]', function () {
		if ( this.hasAttribute( 'data-pivorunas-landing-all' ) ) {
			$( '#pivorunas-landing-form tbody input[type="checkbox"]' ).prop( 'checked', this.checked );
		}
		pivorunasLandingRefresh();
	} );

	$( document ).on( 'click', '[data-pivorunas-landing-save-timer]', function () {
		$( '#pivorunas-landing-form [name="pivorunas_action"]' ).val( 'timer' );
	} );
	$( document ).on( 'click', '[data-pivorunas-landing-toggle]', function () {
		$( '#pivorunas-landing-form [name="pivorunas_action"]' ).val( $( this ).val() );
	} );
	$( document ).on( 'click', '[data-pivorunas-landing-delete]', function () {
		$( '#pivorunas-landing-form [name="pivorunas_action"]' ).val( 'delete' );
	} );
}( jQuery ) );
