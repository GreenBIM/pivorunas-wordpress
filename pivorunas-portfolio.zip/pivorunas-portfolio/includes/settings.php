<?php
/**
 * Landing page pictures. Stored here so they survive a theme change.
 *
 * @package PivorunasPortfolio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Portfolio menu and the landing-page screen.
 */
function pivorunas_portfolio_menu() {
	add_menu_page(
		__( 'Portfolio', 'pivorunas-portfolio' ),
		__( 'Portfolio', 'pivorunas-portfolio' ),
		'edit_posts',
		'pivorunas-portfolio',
		'pivorunas_portfolio_settings_page',
		'dashicons-camera',
		5
	);
	add_submenu_page(
		'pivorunas-portfolio',
		__( 'Landing Page Images', 'pivorunas-portfolio' ),
		__( 'Landing Page Images', 'pivorunas-portfolio' ),
		'edit_posts',
		'pivorunas-portfolio',
		'pivorunas_portfolio_settings_page'
	);
}
add_action( 'admin_menu', 'pivorunas_portfolio_menu', 9 );

/**
 * Saved landing pictures and the slide timer.
 *
 * @return array{timer: int, images: array<int, array{id: int, active: bool, date: int, user: int}>}
 */
function pivorunas_portfolio_landing_data() {
	$data = get_option( 'pivorunas_landing', null );
	if ( ! is_array( $data ) || ! isset( $data['images'] ) || ! is_array( $data['images'] ) ) {
		$data = array(
			'timer'  => 8,
			'images' => array(),
		);
	}
	$data['timer'] = max( 1, absint( $data['timer'] ) );
	return $data;
}

/**
 * Picture IDs that are turned on, in list order.
 *
 * @return int[]
 */
function pivorunas_portfolio_landing_ids() {
	$data = get_option( 'pivorunas_landing', null );
	if ( is_array( $data ) && isset( $data['images'] ) && is_array( $data['images'] ) ) {
		$ids = array();
		foreach ( $data['images'] as $image ) {
			if ( ! empty( $image['active'] ) ) {
				$ids[] = absint( $image['id'] );
			}
		}
		return array_values( array_filter( $ids ) );
	}
	$old = get_option( 'pivorunas_home_ids', array() );
	return is_array( $old ) ? array_values( array_filter( array_map( 'absint', $old ) ) ) : array();
}

/**
 * How many seconds each landing picture stays up.
 */
function pivorunas_portfolio_slide_seconds() {
	$data = pivorunas_portfolio_landing_data();
	return max( 1, absint( $data['timer'] ) );
}

/**
 * Apply Add, Activate, Deactivate, Delete, and the timer.
 */
function pivorunas_portfolio_handle_landing_post() {
	if ( ! isset( $_POST['pivorunas_landing_nonce'] ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_posts' ) ) {
		return;
	}
	check_admin_referer( 'pivorunas_landing', 'pivorunas_landing_nonce' );

	$data   = pivorunas_portfolio_landing_data();
	$action = isset( $_POST['pivorunas_action'] ) ? sanitize_key( wp_unslash( $_POST['pivorunas_action'] ) ) : '';
	$checked = isset( $_POST['pivorunas_checked'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['pivorunas_checked'] ) ) : array();

	if ( 'timer' === $action ) {
		$seconds      = isset( $_POST['pivorunas_slide_timer'] ) ? absint( wp_unslash( $_POST['pivorunas_slide_timer'] ) ) : 8;
		$data['timer'] = max( 1, min( 3600, $seconds ) );
	}

	if ( 'add' === $action ) {
		$raw = isset( $_POST['pivorunas_add_ids'] ) ? sanitize_text_field( wp_unslash( $_POST['pivorunas_add_ids'] ) ) : '';
		$have = array();
		foreach ( $data['images'] as $image ) {
			$have[] = absint( $image['id'] );
		}
		foreach ( explode( ',', $raw ) as $id ) {
			$id = absint( $id );
			if ( ! $id || ! wp_attachment_is_image( $id ) || in_array( $id, $have, true ) ) {
				continue;
			}
			$data['images'][] = array(
				'id'     => $id,
				'active' => true,
				'date'   => time(),
				'user'   => get_current_user_id(),
			);
			$have[] = $id;
		}
	}

	if ( 'delete' === $action && $checked ) {
		$data['images'] = array_values(
			array_filter(
				$data['images'],
				static function ( $image ) use ( $checked ) {
					return ! in_array( absint( $image['id'] ), $checked, true );
				}
			)
		);
	}

	if ( 'activate' === $action || 'deactivate' === $action ) {
		foreach ( $data['images'] as $index => $image ) {
			if ( in_array( absint( $image['id'] ), $checked, true ) ) {
				$data['images'][ $index ]['active'] = ( 'activate' === $action );
			}
		}
	}

	update_option( 'pivorunas_landing', $data );
	wp_safe_redirect( admin_url( 'admin.php?page=pivorunas-portfolio&updated=1' ) );
	exit;
}
add_action( 'admin_init', 'pivorunas_portfolio_handle_landing_post' );

/**
 * Landing Page Images screen.
 */
function pivorunas_portfolio_settings_page() {
	if ( ! current_user_can( 'edit_posts' ) ) {
		return;
	}
	$data = pivorunas_portfolio_landing_data();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Landing Page Images', 'pivorunas-portfolio' ); ?></h1>
		<?php if ( isset( $_GET['updated'] ) ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Saved.', 'pivorunas-portfolio' ); ?></p></div>
		<?php endif; ?>
		<form id="pivorunas-landing-form" method="post">
			<?php wp_nonce_field( 'pivorunas_landing', 'pivorunas_landing_nonce' ); ?>
			<input type="hidden" name="pivorunas_action" value="" />
			<input type="hidden" name="pivorunas_add_ids" value="" />

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="pivorunas-slide-timer"><?php esc_html_e( 'Slide Timer', 'pivorunas-portfolio' ); ?></label></th>
					<td>
						<input id="pivorunas-slide-timer" type="number" min="1" max="3600" step="1" name="pivorunas_slide_timer" value="<?php echo esc_attr( (string) $data['timer'] ); ?>" />
						<?php esc_html_e( 'seconds', 'pivorunas-portfolio' ); ?>
						<p class="description"><?php esc_html_e( 'Sets how long the slide stays on an image.', 'pivorunas-portfolio' ); ?></p>
						<button type="submit" class="button" data-pivorunas-landing-save-timer><?php esc_html_e( 'Save', 'pivorunas-portfolio' ); ?></button>
					</td>
				</tr>
			</table>

			<p>
				<button type="button" class="button button-primary" data-pivorunas-landing-add><?php esc_html_e( 'Add', 'pivorunas-portfolio' ); ?></button>
				<button type="submit" class="button" value="activate" data-pivorunas-landing-toggle disabled><?php esc_html_e( 'Activate', 'pivorunas-portfolio' ); ?></button>
				<button type="submit" class="button" data-pivorunas-landing-delete disabled><?php esc_html_e( 'Delete', 'pivorunas-portfolio' ); ?></button>
			</p>
			<p class="description"><?php esc_html_e( 'Check one or more pictures first. Delete only takes a picture off this list. The file stays in Media.', 'pivorunas-portfolio' ); ?></p>

			<table class="widefat striped pivorunas-landing">
				<thead>
					<tr>
						<td class="check-column"><input type="checkbox" data-pivorunas-landing-all /></td>
						<th><?php esc_html_e( 'Image', 'pivorunas-portfolio' ); ?></th>
						<th><?php esc_html_e( 'Date', 'pivorunas-portfolio' ); ?></th>
						<th><?php esc_html_e( 'Active', 'pivorunas-portfolio' ); ?></th>
						<th><?php esc_html_e( 'Who put it up', 'pivorunas-portfolio' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( ! $data['images'] ) : ?>
						<tr><td colspan="5"><?php esc_html_e( 'No pictures yet. Click Add.', 'pivorunas-portfolio' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( $data['images'] as $image ) : ?>
						<?php
						$id    = absint( $image['id'] );
						$user  = get_userdata( absint( $image['user'] ) );
						$on    = ! empty( $image['active'] );
						$when  = ! empty( $image['date'] ) ? date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), absint( $image['date'] ) ) : '';
						?>
						<tr>
							<th class="check-column" scope="row">
								<input type="checkbox" name="pivorunas_checked[]" value="<?php echo esc_attr( (string) $id ); ?>" data-active="<?php echo $on ? '1' : '0'; ?>" />
							</th>
							<td>
								<?php echo wp_get_attachment_image( $id, array( 72, 72 ) ); ?>
								<?php echo esc_html( wp_basename( (string) get_attached_file( $id ) ) ); ?>
							</td>
							<td><?php echo esc_html( $when ); ?></td>
							<td><?php echo esc_html( $on ? __( 'Yes', 'pivorunas-portfolio' ) : __( 'No', 'pivorunas-portfolio' ) ); ?></td>
							<td><?php echo esc_html( $user ? $user->display_name : __( 'Unknown', 'pivorunas-portfolio' ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</form>
	</div>
	<?php
}